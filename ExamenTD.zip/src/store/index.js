import Vue from 'vue'
import Vuex from 'vuex'
import api from '@/Api/index.js'
Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    dashboard:{},
    detalle_orden:{},
    estados:{},
    login:{},
    oficinas:{},
    ordenes:{}
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})

<template>
  <div>
      <h1>Error</h1>
      <h3>Pagina no encontrada</h3>
      <h5>Verifique la ruta de acceso.</h5>
  </div>
</template>

<script>
export default {
    name:"Error"
}
</script>

<style>

</style>
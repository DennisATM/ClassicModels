<template>
  <div class="col">
    <div class="card">
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <p class="lead">Vitrina</p>
      </div>
    </div>
      <div class="card-body">
          <h3>Bienvenido</h3>
          Bienvenido al sistema de Ordenes e Inventario de ClassicModels.</div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.card-body{
    display: block;
    text-align: start;
}
</style>
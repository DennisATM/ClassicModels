<template>
  <div>
      <Navbar />
      <div class="home__bread mt-5">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item active" aria-current="page">Home>>Monitor de Órdenes</li>
        </ol>
      </nav>
    </div>
    <h5>Monitor de Órdenes</h5>
    <div class="row">
        <div class="col col-sm-12 col-lg-2 border border-info">
            <label for="">Oficina</label> <br>
            <select name="oficina" id="">
            <option v-for="(items, index) in oficinas.oficinas" :key="index">{{items.name}}</option>
            </select>
        </div>
    </div>
  </div>
</template>

<script>
import Navbar from "@/components/Navbar.vue";
import { mapState } from "vuex";
export default {
    components:{
        Navbar,
    },
    computed: {
    ...mapState(["oficinas"]),
  },
}
</script>

<style>

</style>
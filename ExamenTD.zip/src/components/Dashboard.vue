<template>
  <div class="row justify-content-center w-100">
    <div class="col col-sm-12 col-lg-6">
      <div class="col border border-info mt-3 ml-3">
        {{ dashboard.kpis[0].nombre }} <br />
        <div class="row">
          <div class="col">
            <h4>
              {{ dashboard.kpis[0].entregadas }} <br />
              <span class="dash__subtitle">Ordenes Entregadas</span>
            </h4>
          </div>
          <div class="col">
            <h4>
              {{ dashboard.kpis[0].pendientes }} <br />
              <span class="dash__subtitle">Ordenes Pendientes</span>
            </h4>
          </div>
        </div>
      </div>
      <div class="row justify-content-center m-3">
        <h5>Ultimas Ordenes</h5>
        <table class="table table-sm ml-3">
          <thead>
            <tr>
              <th scope="col">N° Orden</th>
              <th scope="col">Cliente</th>
              <th scope="col">Fecha Entrega</th>
              <th scope="col">Estado</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(items, index) in dashboard.utimas_ordenes" :key="index">
              <td>{{ items.num_orden }}</td>
              <td>{{ items.cliente }}</td>
              <td>{{ items.fecha_entrega }}</td>
              <td>{{ items.estado }}</td>
              <td>
                <button type="button" class="btn btn-info">Ver Detalle</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="col col-sm-12 col-lg-6">
      <div class="col border border-info mt-3 ml-3">
        {{ dashboard.kpis[1].nombre }}
        <div class="row">
          <div class="col">
            <h4>
              {{ dashboard.kpis[1].totales }} <br>
              <span class="dash__subtitle">Ordenes Totales</span>
            </h4>
          </div>
          <div class="col">
            <h4>
              {{ dashboard.kpis[1].atrasadas }} <br>
              <span class="dash__subtitle">Ordenes Atrasadas</span>
            </h4>
          </div>
        </div>
      </div>

      <div class="row justify-content-center m-3">
        <h5>Ultimas Devoluciones</h5>
        <table class="table table-sm ml-3">
          <thead>
            <tr>
              <th scope="col">N° Orden</th>
              <th scope="col">Cliente</th>
              <th scope="col">Fecha Devolucion</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(items, index) in dashboard.ultimas_devoluciones" :key="index">
              <td>{{ items.num_orden }}</td>
              <td>{{ items.cliente }}</td>
              <td>{{ items.fecha_entrega }}</td>
              <td>
                <button type="button" class="btn btn-info">Ver Detalle</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
export default {
  data() {
    return {
      user: "",
      password: "",
    };
  },
  computed: {
    ...mapState(["dashboard"]),
  },
};
</script>

<style>
.dash__subtitle {
  font-size: 0.5em;
}

.table {
  font-size: 0.6em;
}
.btn {
  font-size: 0.8em;
}
@media screen and(min-width: 1024px) {
  .table {
    font-size: 1em;
  }

  .btn {
    font-size: 1em;
  }
}
</style>
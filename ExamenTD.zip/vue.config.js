module.exports = {
  lintOnSave: false
}
